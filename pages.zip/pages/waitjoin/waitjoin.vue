<template>
	<view>
		<text>所有的带参加</text>
	</view>
</template>

<script setup>
	
	
</script>

<style lang="scss">

</style>
